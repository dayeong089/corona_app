// import 'package:flutter/material.dart';
// import 'package:provider/provider.dart';
//
// class Page5CounterProvider with ChangeNotifier{
//   int _counter = 5;
//   get counter => _counter;
//
//   Page5CounterProvider(this._counter);
//   this._counter++;
//   notifyListeners();
// }